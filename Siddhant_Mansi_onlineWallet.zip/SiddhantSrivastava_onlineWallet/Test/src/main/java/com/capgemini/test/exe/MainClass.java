package com.capgemini.test.exe;

import java.util.*;
import com.capgemini.test.model.*;
import com.capgemini.test.services.*;
import java.io.*;

public class MainClass {
	
	
	
	public static void main(String[] args) {
		
			Scanner sc = new Scanner(System.in);
			DataStorage.extractWalletUser(); 
			DataStorage.extractWalletAccount();
			NormalServices ns = new NormalServices();
			UserServices us =new UserServices();
			String c="1";
			do {
					
					System.out.println("***************  User Menu   ***************");
					
					switch(ns.startMenuUser()) {
						case 1:	
							ns.startMenuUser2();
							c=ns.backMenu();
							break;
						case 2:
							us.createWallet();
							c=ns.backMenu();
							break;
						case 3:
							System.out.println("Visit Again");
							c="3";
						default: 
							c=ns.backMenu();
					}
					
			}while(c.equals("1"));
				
			System.out.println(DataStorage.getWalletUserStore());
			System.out.println(DataStorage.getWalletAccountStore());
			DataStorage.storeWalletUser();
			DataStorage.storeWalletAccount();
			
			
//			try {
//				File f = new File("C:\\Users\\user\\Desktop\\StoreWalletUser.txt");
//				FileOutputStream file = new FileOutputStream(f);
//				ObjectOutputStream out = new ObjectOutputStream(file);
//				out.writeObject(new HashMap<Integer,WalletUser>());
//				out.close();
//				file.close();
//				System.out.println("Thanks");
//			} catch (Exception e) {
//				System.out.println(e);
//			} 
//			try {
//				File f = new File("C:\\Users\\user\\Desktop\\StoreWalletAccount.txt");
//				FileOutputStream file = new FileOutputStream(f);
//				ObjectOutputStream out = new ObjectOutputStream(file);
//				out.writeObject(new HashMap<Integer,WalletAccount>());
//				out.close();
//				file.close();
//				System.out.println("Thanks");
//			} catch (Exception e) {
//				System.out.println(e);
//			}
			
			
		}
}