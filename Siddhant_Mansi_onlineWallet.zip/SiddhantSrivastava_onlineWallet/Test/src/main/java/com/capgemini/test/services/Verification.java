package com.capgemini.test.services;

import java.util.*;

import com.capgemini.test.model.*;

public class Verification {
	
	
	Scanner sc = new Scanner(System.in);
	
	
	
	public boolean login(String userId,String password) {
		HashMap<Integer,WalletUser> wu = DataStorage.getWalletUserStore();
		int uId;
		try {
			uId=Integer.parseInt(userId);
		}catch(NumberFormatException ex) {
			return false;
		}
		if(wu.containsKey(uId) && wu.get(uId).getPassword().equals(password)) {
			System.out.println("Successfull Login\n");
			System.out.println("***************         User Menu       ***************");
			return true;
		}else {
			System.out.println("Invalid Credentials!");
			return false;
		}
	}
		
	
	public boolean forgotPassword() {
		System.out.println("\n***************      Forgot Password      ***************");
		System.out.println("Enter UserId :- ");
		String uid=sc.nextLine();
		int userId;
		try {
			userId = Integer.parseInt(uid);
		} catch (NumberFormatException e) {
			System.out.println("Invalid User ID");
			System.out.println("Password Recovery Failed");
			return false;
		}
		System.out.println("Enter Name :- ");
		String loginName=sc.nextLine();
		System.out.println("Enter Phone Number :- ");
		String phoneNumber=sc.nextLine();
		HashMap<Integer,WalletUser> wu = DataStorage.getWalletUserStore();
		if(wu.containsKey(userId) && wu.get(userId).getLoginName().equalsIgnoreCase(loginName) && wu.get(userId).getPhoneNumber().equals(phoneNumber)) {
			WalletUser w = wu.get(userId);
			System.out.print("Enter New Password :- ");
			String password=sc.nextLine();
			w.setPassword(password);
			wu.put(userId,w);
			DataStorage.setWalletUserStore(wu);
			return true;
		}else {
			System.out.println("----------Invalid Credentials!");
			System.out.println("----------Password Recovery Failed");
			return false;
		}
		
	}
	
	public boolean checkUserExists(int userId) {
		return false;
	}

}
