package com.capgemini.test.services;

import java.util.*;

import com.capgemini.test.model.*;

import java.io.*;

public class DataStorage {
	
	static HashMap<Integer,WalletUser> walletUserStore = new HashMap<Integer,WalletUser>();
	static HashMap<Integer,WalletAccount> walletAccountStore = new HashMap<Integer,WalletAccount>();

	
	public static void extractWalletUser() {
		try {
			File f = new File("C:\\Users\\user\\Desktop\\StoreWalletUser.txt");
			FileInputStream file = new FileInputStream(f);
			ObjectInputStream in = new ObjectInputStream(file);
			walletUserStore = (HashMap<Integer, WalletUser>) in.readObject();
			in.close();
			file.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	
	public static void extractWalletAccount() {
		try {
			File f = new File("C:\\Users\\user\\Desktop\\StoreWalletAccount.txt");
			FileInputStream file = new FileInputStream(f);
			ObjectInputStream in = new ObjectInputStream(file);
			walletAccountStore = (HashMap<Integer, WalletAccount>) in.readObject();
			in.close();
			file.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	
	
	
	public static void storeWalletUser() {
		try {
			File f = new File("C:\\Users\\user\\Desktop\\StoreWalletUser.txt");
			FileOutputStream file = new FileOutputStream(f);
			ObjectOutputStream out = new ObjectOutputStream(file);
			out.writeObject(walletUserStore);
			out.close();
			file.close();
		} catch (Exception e) {
			System.out.println(e);
		} 
	}
	
	
	public static void storeWalletAccount() {
		try {
			File f = new File("C:\\Users\\user\\Desktop\\StoreWalletAccount.txt");
			FileOutputStream file = new FileOutputStream(f);
			ObjectOutputStream out = new ObjectOutputStream(file);
			out.writeObject(walletAccountStore);
			out.close();
			file.close();
		} catch (Exception e) {
			System.out.println(e);
		} 
	}
	
	
	
	
	public static void addUser(WalletUser wu) {
		
		if((walletUserStore.get(wu.getUserId()).getPhoneNumber()).equals(wu.getPhoneNumber())) {
			System.out.println("User Already Exists");
		}else {
			walletUserStore.put(wu.getUserId(),wu);
			walletAccountStore.put(wu.getUserId(),new WalletAccount(wu.getUserId(),0.0,true,null));
		}
		
	}
	
	
	
	
	public static HashMap<Integer, WalletUser> getWalletUserStore() {
		return walletUserStore;
	}
	
	
	

	public static HashMap<Integer, WalletAccount> getWalletAccountStore() {
		return walletAccountStore;
	}

	
	
	
	public static void setWalletUserStore(HashMap<Integer, WalletUser> walletUserStore) {
		DataStorage.walletUserStore = walletUserStore;
	}
	
	
	

	public static void setWalletAccountStore(HashMap<Integer, WalletAccount> walletAccountStore) {
		DataStorage.walletAccountStore = walletAccountStore;
	}

	
	
	
//For first time execution copy this code in main and execute
//	try {
//		File f = new File("C:\\Users\\Siddhant Srivastava\\Documents\\workspace-sts-3.9.6.RELEASE\\Test\\Data Storage\\StoreWalletUser.txt");
//		FileOutputStream file = new FileOutputStream(f);
//		ObjectOutputStream out = new ObjectOutputStream(file);
//		out.writeObject(new HashMap<Integer,WalletUser>());
//		out.close();
//		file.close();
//		System.out.println("Thanks");
//	} catch (Exception e) {
//		System.out.println(e);
//	} 
//	try {
//		File f = new File("C:\\Users\\Siddhant Srivastava\\Documents\\workspace-sts-3.9.6.RELEASE\\Test\\Data Storage\\StoreWalletAccount.txt");
//		FileOutputStream file = new FileOutputStream(f);
//		ObjectOutputStream out = new ObjectOutputStream(file);
//		out.writeObject(new HashMap<Integer,WalletAccount>());
//		out.close();
//		file.close();
//		System.out.println("Thanks");
//	} catch (Exception e) {
//		System.out.println(e);
//	}
	
	
}
