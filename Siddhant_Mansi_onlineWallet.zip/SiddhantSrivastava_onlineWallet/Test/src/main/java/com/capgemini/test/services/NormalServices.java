package com.capgemini.test.services;

import java.util.Scanner;

public class NormalServices {
	
	
	Scanner sc = new Scanner(System.in);
	UserServices us = new UserServices();
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	//Correct
//	public int startMenu() {
//		System.out.println("Press 1 for User Login ");
//		System.out.println("Press 2 for Admin Login ");
//		System.out.println("Press 3 for Exit");
//		int i1=0;
//		do {
//			i1++;
//			String choice=sc.nextLine();
//			if(choice.equals("1") || choice.equals("2")|| choice.equals("3")) {
//				return Integer.parseInt(choice);
//			}
//			else {
//				if(i1<3) {
//					System.out.println("----------Please enter a valid choice");	
//				}else {
//					System.out.println("----------You have exceeded the limit!");
//					System.out.println("----------Try Again After Some Time.......");
//				}
//			}
//		}while(i1<3);
//		return 0;
//	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	//Correct
	public int startMenuUser() {
		System.out.println("Press 1 for Login");
		System.out.println("Press 2 for Create Account");
		System.out.println("Press 3 for Exit");
		int i=0;
		do {
			i++;
			String choice=sc.nextLine();
			if(choice.equals("1") || choice.equals("2") || choice.equals("3")) {
				return Integer.parseInt(choice);
			}
			else {
				if(i<3) {
					System.out.println("----------Please enter a valid choice");	
				}else {
					System.out.println("----------You have exceeded the limit!");
					System.out.println("----------Try Again After Some Time.......");
				}
			}
		}while(i<3);
		return 0;
		
	}
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////

	//correct
	public boolean startMenuUser2() {
		
		int i3=0;
		
		do {
				System.out.println("\n***************    Enter User Details    ***************");
				System.out.println("Enter User ID");
				String uId1=sc.nextLine();
				System.out.println("Enter Password :- ");
				String password=sc.nextLine();
				
					if(new Verification().login(uId1,password)) {
						int userId=0;
						try {
							userId=Integer.parseInt(uId1);
						}catch(NumberFormatException e) {
							System.out.println(e);
						}
						String k="0";
						do {
							switch(startMenuUser3()) {
								case 1:
									System.out.println("\n***************       Add Money           ***************");
									us.AddAmount(userId);
									break;
								case 2:
									System.out.println("\n***************       View Balance        ***************");
									us.showBalance(userId);
									break;
								case 3:
									System.out.println("\n***************      Tranfer Money        ***************");
									us.transferMoney(userId);
									break;
								case 4:
									System.out.println("\n***************       View profile        ***************");
									us.viewProfile(userId);
									break;
								case 5:
									System.out.println("\n***************    View Wallet Details    ***************");
									us.viewAccount(userId);
									break;
								case 6:
									System.out.println("Visit Again");
									return false;
								default:
									System.out.println("----------There may be problem in the server we will soon respond...");
									break;
							}
						}while(k.equalsIgnoreCase("p"));
					}else {
						System.out.println("Press F for forgot Password");
						System.out.println("Press M for Main Menu");
						System.out.println("Press any other key to re-enter credentials ");
						String forgot=sc.nextLine();
						if(forgot.equals("f") || forgot.equals("F") ) {
							boolean f = new Verification().forgotPassword();
							if(f) {
								System.out.println("--------Password updated successfully");
								return true;
							}
						}if(forgot.equalsIgnoreCase("m")) {
							return false;
						}
					}
					if(i3<3) {
						System.out.println("----------Please Enter Valid User Details");
					}else {
						System.out.println("----------Sorry you have exceeded the limit");
						return false;
					}
			
		}while(i3<3);
		return false;
		
	}
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	//Correct
	
	public int startMenuUser3() {
		System.out.println("Press 1 for Add Money");
		System.out.println("Press 2 for Show Money");
		System.out.println("Press 3 for Transfer Money");
		System.out.println("Press 4 for View Profile");
		System.out.println("Press 5 for Wallet Details");
		System.out.println("Press 6 for Exit ");
		int i1=0;
		do {
			i1++;
			String choice=sc.nextLine();
			if(choice.equals("1") || choice.equals("2") || choice.equals("3") || choice.equals("4") || choice.equals("5") || choice.equals("6")) {
				return Integer.parseInt(choice);
			}
			else {
				if(i1<3) {
					System.out.println("----------Please enter a valid choice");	
				}else {
					System.out.println("----------You have exceeded the limit!");
					System.out.println("----------Try Again After Some Time.......");
				}
			}
		}while(i1<3);
		return 0;
	}
	
	public String backMenu() {
		System.out.println("--------Press 1 for main menu\n--------Press 2 for Exit");
		int k=0;
		do {
			k++;
			String s=sc.nextLine();
			if(s.equals("1") || s.equals("2")) {
				return s;
			}else {
				if(k<3) {
					System.out.println("Please enter a valid choice");
				}else {
					System.out.println("Sorry you have exceeded the limit");
				}
			}
		}while(k<3);
		return "2";
	}

}
