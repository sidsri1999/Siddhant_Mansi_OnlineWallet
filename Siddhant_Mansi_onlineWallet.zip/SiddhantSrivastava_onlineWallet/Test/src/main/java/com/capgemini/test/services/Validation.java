package com.capgemini.test.services;

import java.util.regex.*;

public class Validation {
	
	public static boolean userNamePassValidation( String userNamePass) {
		return Pattern.matches("^[a-zA-Z0-9_@]{5,15}?",userNamePass);
	}
	
	public static boolean phoneNumberValidation( String phoneNumber) {
		return Pattern.matches("[789][0-9]{9}",phoneNumber);
	}
	
	public static boolean loginNameValidation( String loginName) {
		return Pattern.matches("^[A-Za-z][a-zA-Z\\.\\s]+$",loginName);
	}
	

}
